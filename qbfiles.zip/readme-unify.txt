Unified FB/QB GAME.EXE source.

All differences are contained in compat.bi and compat.bas (and there are a couple of extra files in the FreeBasic version).

To build in QB either:

A - Copy all source files from FBOHR to OHRRPGCE except allmodex.bas and fontdata.bi, add the files from this archive (replacing compat.bi and compat.bas), and compile as usual.

or

B - Apply the unify.patch to the files in OHRRPGCE and add compat.bi and compat.bas, then compile as usual.

Shared source files
-------------------
allmodex.bi
bglobals.bi
bmod.bas
bmodsubs.bas
const.bi
game.bas
gglobals.bi
menustuf.bas
moresubs.bas
yetmore.bas
yetmore2.bas

Different files
---------------
compat.bi
compat.bas

Unique to FB
------------
allmodex.bas
fontdata.bi
